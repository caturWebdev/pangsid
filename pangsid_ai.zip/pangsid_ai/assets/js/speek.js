const TOKEN = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6ImNhdHVyX2p3dCIsImV4cCI6MTc0OTgxNTcxOCwiaWF0IjoxNzQ4NjA2MTE4fQ.SSjD9zw4jxeCfnPUZL2JtoE-Us1Wmr_3odJB-_yUp-w"
var currentPlaying;

async function get_audio(button, text = "") {
    if (!text) {
        alert("Teks tidak boleh kosong");
        return;
    }

    const myHeaders = new Headers();
    myHeaders.append("Content-Type", "application/json");
    myHeaders.append("Authorization", "Bearer " + TOKEN);

    const requestOptions = {
        method: "POST",
        headers: myHeaders,
        body: JSON.stringify({ text: text }),
        redirect: "follow",
    };

    let oriBtnText = button.innerText;
    button.disabled = true;
    button.innerText = "Mohon tunggu...";
    document.getElementById('downloadBtn').style.display = "none"; // Sembunyikan download saat loading

    const raw = await fetch("https://cutil.vercel.app/generate/tts", requestOptions);
    const hasil = await raw.json();
    const audioBase64 = hasil.audioContent;

    if (!audioBase64) {
        button.innerText = oriBtnText;
        alert(hasil.error || "Terjadi Kesalahan");
        return;
    } else {
        button.innerText = "Memutar Audio...";
        const playlist = [
            new Howl({ src: ['assets/sound/opening.wav'] }),
            new Howl({ src: [`data:audio/mp3;base64,${audioBase64}`] }),
            new Howl({ src: ['assets/sound/closing.wav'] })
        ];
        currentPlaying = playlist;
        const downloadBtn = document.getElementById('downloadBtn');
        downloadBtn.href = `data:audio/mp3;base64,${audioBase64}`;
        downloadBtn.download = "tts_audio.mp3";
        downloadBtn.style.display = "inline-block";
        let index = 0;

        function playNext() {
            if (index < playlist.length) {
                playlist[index].play();
                playlist[index].once('end', () => {
                    index++;
                    playNext();
                });
            } else {
                button.disabled = false;
                button.innerText = oriBtnText;
            }
        }

        playNext();
    }
}

function customPesan(text = false) {
    document.getElementById('custom_panggil').value = text || "Ketik teks disini...";
}

function stopAllAudio() {
    if (currentPlaying.length > 0) {
        currentPlaying.forEach(sound => {
            if (sound.playing()) {
                sound.stop();
            }
        });
        currentPlaying = [];
    }
}
