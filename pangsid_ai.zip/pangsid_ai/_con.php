<?php
	// KONEKSI DATABASE SIPP //
	$servername = "localhost";
	$username = "root";
	$password = "sql4dm1n";
	$dbname = "sipp32";
	// ABAIKAN SAJA JIKA TIDAK MENGGUNAKAN DATABASE SIPP //
	
	$conn = mysqli_connect($servername, $username, $password, $dbname) or die("Connection failed: " . mysqli_connect_error());
	
	$system=mysqli_query($conn, "SELECT * from sys_config");
	while( $row=mysqli_fetch_array($system) ) {  
		if ($row['id']=='62'){
			$nama_pn=$row['value'];
		}
		if ($row['id']=='63'){
			$alamat_pn=$row['value'];
		}
		if ($row['id']=='75'){
			$zona=$row['value'];
		}
		if ($row['id']=='80'){
			$versi=$row['value'];
		}
	}

?>
