<div class="row">
    <div class="col-md-12">
        <div class="note note-default">
            <h3 class="text-info"><b>PANGGILAN AUDIO</b></h3>
            <ul>
                <li><p>Untuk panggil keruang sidang, dan detil perkara klik Nomor Perkara.</p></li>
                 <li><p>Untuk panggil nomor perkara yang tidak ada pada jadwal sidang hari ini ketik nomor perkara pada kolom <font class='text-danger bold'><i class='fa fa-search'> </i> &nbsp Pencarian :</font>.</p></li>
            </ul>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-md-12">
        <div class="portlet box green-jungle ">
            <div class="portlet-title">
                <div class="caption">
                    <i class="fa fa-bank"> </i> Pengumuman</div>
                <div class="tools"> </div>
            </div>
            <div class="portlet-body">
                <button type="button" class="btn btn-info" data-toggle="modal" data-target="#customModal">Buat Panggilan</button>
            </div>
        </div>
        <div class="portlet box green-jungle ">
            <div class="portlet-title">
                  <div class="caption">
                    <i class="fa fa-edit"></i> Jadwal tanggal : 
                    <input type="date" id="filterTanggal" value="<?php echo date('Y-m-d'); ?>" style="border:none; background:transparent; font-weight:bold; cursor:pointer;">
                </div>
            </div>
            <div class="portlet-body">
                <table class="table table-striped table-bordered table-hover dt-responsive" width="100%" id="cats">
                    <thead>
                        <tr class="bg-primary">
                        <th class="all">Nomor Perkara</th>
                        <th class="all">Tgl Sidang</th>
                        <th class="all">Ruang Sidang</th>
                        <th class="all">Para Pihak</th>
                        <th class="none">Majelis Hakim :</th>
                        <th class="none"></th>
                        
                        </tr>
                    </thead>

                    </table>
                </table> 
            </div>
        </div>
        
                <audio id="pembukaan" onended="endOpening();">
                      <source src="assets/sound/opening.wav" type="audio/mpeg">
                </audio>
                <audio id="closing">
                      <source src="assets/sound/closing.wav" type="audio/mpeg">
                </audio>
    </div>
</div>

<script type="text/javascript">
    $(document).ready(function () {
    let table = $('#cats').DataTable({
        "processing": true,
        "serverSide": true,
        "ajax": {
            "url": "_query_sipp.php",
            "type": "POST",
            "data": function (d) {
                d.tanggal_sidang = $('#filterTanggal').val();  // kirim tanggal filter ke backend
            },
            error: function (xhr, error, thrown) {
                console.error("Ajax Error:", error);
                alert("Data SIPP tidak bisa ditampilkan, cek koneksi database. Atau abaikan pesan ini jika hanya menggunakan Fitur Audio Pengumuman");
            }
        },
        "columns": [
            { "data": 0 },
            { "data": 1 },
            { "data": 2 },
            { "data": 3 },
            { "data": 4 },
            { "data": 5 } 
        ],
        "order": [[1, "desc"]],
        "language": {
            "processing": "Memuat data...",
            "zeroRecords": "Tidak ada data ditemukan",
            "emptyTable": "Data tidak tersedia",
            "info": "Menampilkan _START_ sampai _END_ dari _TOTAL_ data",
            "infoEmpty": "Menampilkan 0 data",
            "lengthMenu": "Tampilkan _MENU_ data",
            "search": "Cari:",
            "paginate": {
                "first": "Pertama",
                "last": "Terakhir",
                "next": "Berikutnya",
                "previous": "Sebelumnya"
            },
            "loadingRecords": "Sedang memuat...",
            "infoFiltered": "(difilter dari total _MAX_ data)",
            "error": "Data tidak bisa ditampilkan, cek koneksi SIPP atau abaikan pesan ini jika tidak terkoneksi ke DB SIPP"
        }
    });

    // Debounce search biasa
    let debounceTimeout;
    $('#cats_filter input').unbind().bind('input', function () {
        let searchTerm = this.value;

        clearTimeout(debounceTimeout);
        debounceTimeout = setTimeout(() => {
            table.search(searchTerm).draw();
        }, 1000);
    });

    // Saat tanggal berubah, reload datatable dengan filter tanggal
    $('#filterTanggal').on('change', function () {
        table.ajax.reload();
    });
});
</script>

