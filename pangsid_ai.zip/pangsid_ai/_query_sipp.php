<?php
error_reporting(E_ALL & ~E_DEPRECATED & ~E_WARNING & ~E_NOTICE);
ini_set('display_errors', 0);
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");

include "_con.php";

// Utility functions
function sanitize_row($row) {
    foreach ($row as $key => $value) {
        if (is_null($value)) $row[$key] = "";
    }
    return $row;
}

function clear_text($val) {
    $val = preg_replace([
        "/(, ?sh|s\.h)/i",
        "/(<br\s*\/?>)/i",
        "/<\/a>/",
        "/(pgl\.?|pgl)/i",
        "/(als\.?|als)/i",
        "/panitera pengganti/i",
        "/:/",
        "/ruang sidang ruang sidang/i",
        "~[^a-z0-9:,. ]~i"
    ], [
        ' S H ', ', ', ' ', 'panggilan', 'alias', ' ', ' ', 'ruang sidang', ''
    ], strtolower($val));
    return trim($val);
}

// Get DataTables request parameters safely
$draw = intval($_REQUEST['draw'] ?? 0);
$row = intval($_REQUEST['start'] ?? 0);
$rowperpage = intval($_REQUEST['length'] ?? 10);
$columnIndex = intval($_REQUEST['order'][0]['column'] ?? 0);
$columnName = $_REQUEST['columns'][$columnIndex]['data'] ?? 'tanggal_sidang';
$columnSortOrder = $_REQUEST['order'][0]['dir'] ?? 'asc';
$searchValue = strtolower(trim($_REQUEST['search']['value'] ?? ''));
$searchValueEscaped = mysqli_real_escape_string($conn, $searchValue);
$tanggal_sidang = $_POST['tanggal_sidang'] ?? '';

// Search Query
// $searchQuery = "";
if ($searchValueEscaped !== '') {
    $like = "'" . $searchValueEscaped . "%'";
    $searchQuery = " AND (
        nomor_perkara LIKE $like OR
        pihak1_text LIKE $like OR
        pihak2_text LIKE $like OR
        para_pihak LIKE $like OR
        majelis_hakim_nama LIKE $like OR
        panitera_pengganti_text LIKE $like
    )";
}
if (!empty($tanggal_sidang)) {
    $tanggal_sidang_esc = mysqli_real_escape_string($conn, $tanggal_sidang);
    $searchQuery .= " AND DATE(tanggal_sidang) = '$tanggal_sidang_esc' ";
}
// Total records
$totalRecords = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as allcount FROM v_jadwal_sidang"))['allcount'];
// Total filtered
$totalRecordwithFilter = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as allcount FROM v_jadwal_sidang WHERE 1 $searchQuery"))['allcount'];

// Main query
$sql_query = "SELECT id, alur_perkara_id, perkara_id, tanggal_sidang, sidang_keliling, jam_sidang, agenda,
    IFNULL(ruangan, 'utama') AS ruangan, ditunda, nomor_perkara,
    pihak1_text, pihak2_text, para_pihak, pihak_dipublikasikan,
    majelis_hakim_nama, panitera_pengganti_text, keterangan
    FROM v_jadwal_sidang WHERE 1 $searchQuery
    ORDER BY $columnName $columnSortOrder
    LIMIT $row, $rowperpage";

$result = mysqli_query($conn, $sql_query);
$data = [];

while ($row = mysqli_fetch_assoc($result)) {
    $row = sanitize_row($row);
    $noper = trim(strtolower($row['nomor_perkara']));
    $nomor_speech = str_replace(['pn', '/', '.'], [' P N', ' ', ' '], $noper);
    $nomor_speech = preg_replace('/[\x00-\x1F\x7F]/u', '', $nomor_speech);

    $pihak1 = str_replace("<br />", " ", $row['pihak1_text']);
    $para_pihak = clear_text($row['para_pihak']);
    $alurnya = $row['alur_perkara_id'];

    // Audio buttons
    $btn_jaksa = '';
    if ($alurnya > 100 && $row['pihak_dipublikasikan'] == 'T') {
        $para_pihak = ' ' . clear_text($pihak1) . ", dan terdakwa. ";
        $btn_jaksa = "<button class='btn btn-success btn-sm btn-audio text-white' onclick='get_audio(this,\"Jaksa Penuntut Umum " . clear_text($pihak1) . " sidang dengan Nomor Perkara $nomor_speech, Akan dilaksanakan.\")'>Jaksa</button>";
    }

    $majelis = clear_text($row['majelis_hakim_nama']);
    $panitera = clear_text($row['panitera_pengganti_text']);
    $ruang = trim(strtolower($row['ruangan']));

    $teks_hakim = "Kami informasikan kepada yang mulia $majelis. Sidang Nomor Perkara $nomor_speech siap untuk dilaksanakan di ruang sidang $ruang terima kasih";
    $teks_panitera = "Kami informasikan kepada panitera pengganti $panitera, sidang Nomor Perkara $nomor_speech siap untuk dilaksanakan di ruang sidang $ruang terima kasih";
    $teks_pihak = "Kami informasikan kepada pihak $para_pihak. Perkara nomor $nomor_speech silahkan masuk ke ruang sidang $ruang terima kasih";

    $btn_parapihak = "Para Pihak";
    if (strlen($teks_pihak) > 250) {
        $teks_pihak = "Mohon perhatian, para pihak Perkara Nomor $nomor_speech silahkan masuk ke ruang sidang $ruang";
        $btn_parapihak = "Para Pihak.";
    }

    $tombol_panggil = "
        <button class='btn btn-info btn-sm btn-audio text-white' onclick='get_audio(this,\"$teks_hakim\",\"{$row['nomor_perkara']}\")'>Hakim</button>
        <button class='btn btn-warning btn-sm btn-audio text-white' onclick='get_audio(this,\"$teks_panitera\",\"{$row['nomor_perkara']}\")'>Panitera</button>
        <button class='btn btn-danger btn-sm btn-audio text-white' onclick='get_audio(this,\"$teks_pihak\",\"{$row['nomor_perkara']}\")'>$btn_parapihak</button>
        $btn_jaksa
        <button class='btn btn-primary btn-sm btn-audio text-white' onclick='get_audio(this,\"Kami informasikan kepada petugas piket. untuk segera menjaga persidangan di ruang sidang $ruang\")'>Piket</button>
        <button class='btn btn-primary btn-sm btn-audio text-white' onclick='get_audio(this,\"Kami informasikan kepada pihak keamanan. untuk menjaga persidangan di ruang sidang $ruang\")'>Keamanan</button>";

    $data[] = [
        '<button class="btn btn-primary btn-block text-white">' . $row['nomor_perkara'] . '</button>',
        !empty($row["tanggal_sidang"]) ? (new DateTime($row["tanggal_sidang"]))->format('d-m-Y') : null,
        $row['ruangan'],
        $row['para_pihak'],
        '<br>' . $row['majelis_hakim_nama'].'<br>' . str_replace("Panitera Pengganti:", "<b>Panitera Pengganti:</b><br>", $row['panitera_pengganti_text']),
        $tombol_panggil,
    ];
}

// Output
$response = [
    "draw" => $draw,
    "iTotalRecords" => $totalRecords,
    "iTotalDisplayRecords" => $totalRecordwithFilter,
    "aaData" => $data
];

echo json_encode($response);
?>
