<?php
error_reporting(E_ALL & ~E_NOTICE & ~E_WARNING);
ini_set('display_errors', 0);
?>
<!DOCTYPE html>
<html lang="en">
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />

<head>
  <meta charset="utf-8" />
  <title>PANGSID</title>
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta content="width=device-width, initial-scale=1" name="viewport" />
  <meta content="" name="description" />
  <meta content="" name="catur adi sukrisno" />
  <link href="assets/plugins/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
  <link href="assets/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
  <link href="assets/plugins/datatables/datatables.min.css" rel="stylesheet" type="text/css" />
  <link href="assets/css/layout.min.css" rel="stylesheet" type="text/css" />
  <link rel="shortcut icon" href="favicon.ico" />
</head>
<script type="text/javascript" language="javascript" src="assets/js/jquery.js"></script>
</head>

<body>
  <div class="wrapper">

    <div id="customModal" class="modal fade" role="dialog">
      <div class="modal-dialog modal-col-red">
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal">&times;</button>
            <h4 class="modal-title">PENGUMUMAN</span></h4>
          </div>
          <div class="modal-body">
            <div class="btn-group btn-group-justified" style="margin-bottom: 10px;">
              <a class="btn btn-primary"
                onclick="customPesan('Kami informasikan kepada seluruh hakim, pegawai dan ppnpm , Apel pagi akan segera dimulai. Seluruh pegawai mohon segera berkumpul. Terima kasih')">Apel
                Pagi</a>
              <a class="btn btn-success"
                onclick="customPesan('Kami informasikan kepada seluruh hakim, pegawai dan ppnpm , Apel sore akan dimulai. Seluruh pegawai dimohon berkumpul. Terima kasih.')">Apel
                Sore</a>
              <a class="btn btn-warning"
                onclick="customPesan('Kami informasikan kepada seluruh hakim, pegawai dan ppnpm , Rapat harian akan segera dimulai. Mohon peserta rapat menuju ke ruang rapat. Terima kasih.')">Rapat
                Harian</a>
              <a class="btn btn-info"
                onclick="customPesan('Kami informasikan kepada seluruh hakim, pegawai dan ppnpm , Rapat Bulanan akan segera dimulai. Mohon peserta rapat menuju ke ruang rapat. Terima kasih.')">Rapat
                Bulanan</a>
            </div>
            <textarea id="custom_panggil" class="form-control" rows="5"
              placeholder="Tulis teks yang ingin dipanggil di sini..."></textarea>
          </div>
          <div class="modal-footer">
            <a id="downloadBtn" style="display: none;" class="btn btn-primary">⬇️ Download Audio</a>


            <button class="btn btn-success"
              onclick="get_audio(this, document.getElementById('custom_panggil').value)">Panggil</button>

            <button type="button" class="btn btn-default" data-dismiss="modal" onclick="stopAllAudio()">Batal</button>
          </div>
        </div>
      </div>
    </div>

    <div class="container-fluid">
      <div class="page-content" style="padding-top:30px;margin-top: 20px;">
        <div class="page-content-container">
          <div class="page-content-row">
            <div class="page-sidebar">
              <img src="assets/img/logo.png" alt="Logo"> </a>
              <div class="breadcrumbs" style="margin-top:-10px;">
                <h3 class="bold text-center">PANGGILAN AUDIO</h3>
                <h3 class="bold text-center"><?php echo strtoupper($nama_pn); ?></h3>
                <h5 class="text-center" href="#"><?php echo $alamat_pn ?></h5>
              </div>
            </div>
            <div class="page-content-col">
              <div id="pages">
                <?php include "hari_ini.php" ?>
              </div>
            </div>
          </div>
          <p style="background:#444;color:#C8C100;padding:10px;"> 2017 &copy; &nbsp;|&nbsp; Cats<a target="_blank"
              href="https://www.facebook.com/amandaaisha515"><?php echo strtoupper($nama_pn); ?></a>
          </p>
          <a href="#index" class="go2top">
            <i class="icon-arrow-up"></i>
          </a>
        </div>
      </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/howler@2.2.4/dist/howler.min.js"></script>
    <script src="//cdn.datatables.net/2.3.1/js/dataTables.min.js" type="text/javascript"></script>
    <script src="assets/plugins/datatables/datatables.min.js" type="text/javascript"></script>
    <script src="assets/plugins/bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
    <script src="assets/js/speek.js" type="text/javascript"></script>
</body>

</html>